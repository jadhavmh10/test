<!DOCTYPE html> 
<style>
    .tatal{
        float: left;
        font-family: fantasy;
        font-size: 18px;
    }
    .hr{
        margin-top: 20px;
        margin-bottom: 20px;
        border: 12;
        border-color: red;
        border-top: 1px solid #eee;
    }

</style>


<html lang="en">
    <body>
        <div id="wrapper">
            <!----------------------------------------Start Header----------------------------------->
            <?php $this->load->view("admin/header"); ?>
            <!--------------------------------------End Header----------------------------------->
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header">Total Expenditure and Income Detail's</h3>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row col-md-12">
                    <form name="search" method="post">
                        <div>
                            <div class="col-md-1 col-sm-2"> <label>StartDate: </label> </div> 
                            <div class="col-md-2 col-sm-2"><input type="date" name="start" format="dd-mm-yyyy" style="line-height: 16px;"></div>
                        </div>
                        <div> 
                            <div class="col-md-2 col-sm-2"> <label> EndDate: </label></div>
                            <div class="col-md-2 col-sm-2"><input type="date" name="end"  style="line-height: 16px;"></div>
                        </div>
                        <div> 
                            <div class="col-md-2 col-sm-2">  <label> Select Shop:</label></div>

                            <div class="col-md-2 col-sm-2"><select name="shopname" id="shopname">
                                    <option value="">Select Shop</option>
                                    <?php
                                    if (count($shoplist) > 0) {
                                        foreach ($shoplist as $val) {
                                            ?>
                                            <option value="<?php echo $val['id']; ?>"><?php echo $val['shop_name']; ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select></div>
                        </div>
                        <div class="col-md-1 col-sm-1">
                            <input type="submit" name="submit" value="submit">
                        </div>
                    </form>
                </div>
                <br><br><br><br>
                <div class="row">

                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <h4> <strong> Income Details.</strong></h4>    
                        <table id="income" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Shop Name</th>
                                    <th>Income Sourse</th>
                                    <th>Ammount</th>
                                    <th>DELETE</th>

                                </tr>
                            </thead>
                            <tbody>

                                <?php
                                if (count($income) > 0) {
                                    foreach ($income as $val) {
                                        ?>
                                        <tr>
                                            <td><?php echo date("d-m-Y", strtotime($val['db_add_date'])); ?></td>
                                            <td><?php echo $val['shop_name']; ?></td>
                                            <td><?php echo $val['incomesource']; ?></td>
                                            <td align="right"><?php echo $val['ammount']; ?></td>
                                            <td><a href="#">DELETE</a></td>
                                        </tr>
                                        <?php
                                    }
                                }
                                ?>
                            </tbody>
                            <tfoot>

                            </tfoot>
                        </table>
                    </div>



                </div>


                <div class="row">
                    <div class="col-md-12">
                        <div class="col-md-12 col-sm-12 tatal">Total Income:<?php
                            if ($totalincome[0]['ammount'])
                                echo($totalincome[0]['ammount']);
                            else {
                                echo 0;
                            }
                            ?></div>

                    </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12"> <hr class="hr"></div>

            </div>
        </div>
        <!-- /#wrapper -->

        <!-----------------------------------Start Footer-------------------------------->
        <?php $this->load->view("admin/footer"); ?>

        <!-------------------------------------End Footer-------------------------------------->
    </body>

</html>

<script>
    $(document).ready(function () {
//        $('#expense').DataTable();
//        $('#income').DataTable();
    });

    $(document).ready(function () {
        $('#addshop').validate({
            rules: {
                shopcode: {
                    required: true
                },
                shopname: {
                    required: true
                },
                shoptype: {
                    required: true
                }
            },
            messages: {
                shopcode: {
                    required: "Please Enter shopcode name."
                },
                shopname: {
                    required: "Please Enter shop name."
                },
                shoptype: {
                    required: "Please Enter shop Type."
                }
            }
        });
    });

</script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>