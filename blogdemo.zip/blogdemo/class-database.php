<?php
 
class database{

	var $host;
	var $username;
	var $password;
	var $database;
	var $connid;
	var $db_error;
	var $sql;
	var $cachefile ; 

	//constructor
	function database($db,$dbhost=null)
	{
		
		$this->host=DB_HOST_SLAVE;
		if($dbhost==null){
			$this->host = DB_HOST;			
		}else if($dbhost==DB_HOST_SLAVE){
			$this->host = DB_HOST_SLAVE;			
		}
		$this->username=DB_USER_NAME;
		$this->password=DB_USER_PASSWORD;
		$this->database=$db;
		$this->cachefile = dirname(__FILE__).'/dbcachejuly2016'; 
	}

	//make database connection
	function db_connect()
	{
		$this->connid=mysql_connect($this->host,$this->username,$this->password); // OR die("Connection to database fails");
		//mysql_select_db($this->database,$this->connid);
		if(!$this->connid){
		 return false;
		}else{
		 mysql_select_db($this->database,$this->connid);
		 return true;
		}

		//return true;
	}

	//close mysql connection
	function db_disconnect()
	{
		mysql_close($this->connid);

		return true;
	}
	
	//executes query
	function db_query($sql)
	{
		$result=mysql_query($sql);
		
		$this->db_error=mysql_error();
		
		$this->show_sql_err=1;

		if($this->db_error && $this->show_sql_err){
			//echo "<b>".htmlentities($sql)."</font><br>";
			//echo $this->db_error."</b>";
			//echo "<font><b>Sorry, an error has occurred.<br>Please close the window, refresh the page and try again</b></font>";
		}

		return $result;
	}
	
	function show_db_error()
	{
		echo '<br><font color="#FF0000" size="2pt"><b>ERROR:'.$this->db_error.'</b><hr>SQL:'.htmlspecialchars($sql).'</font>';
		exit;		
	}

	function db_fetch_array($result,$type=MYSQL_ASSOC)
	{
		return mysql_fetch_array($result,$type);
	}


	function db_num_rows($result)
	{
		return mysql_num_rows($result);
	}

	function db_fetch_row($result)
	{
		return mysql_fetch_row($result);
	}

	function db_count($result)
	{
		return mysql_num_rows($result);
	}

	//return mysql error, if any
	function db_error()
	{
		$err=mysql_error();

		if($err){
			$this->db_error= '<font class="dberror"><li>'.$err.'</font>';
		}
	}

	function db_insert_id()
	{
		return mysql_insert_id();
	}


	function get_affected_rows()
	{
		return mysql_affected_rows();
	}
	
	function db_fetch_all($result,$isSingleValue=0,&$counter=0){
	 	$all_rows=array();
	 	$counter=0;
	  	while($row = mysql_fetch_assoc($result)){
	  		if($isSingleValue==1) $all_rows[$counter]=array_shift($row);
	  		else $all_rows[$counter]=$row;
	  		
	   		$counter++;
	 	 }
	  return $all_rows;
	}
	
	/**
	* Free the memory of db result 
	* @param resource $result
	* @return bool
	*/
	function db_free_result($result){
	  return mysql_free_result($result);
	}
	
	/**
	* Execute Select Query and Return the result in the array format
	* @param string $sql 
	* @param integer $record_count(byReference)
	* @return array
	*/ 
	function db_ExecQry($sql,&$record_count=0){
	 $arr = array();
		 $res =	$this->db_query($sql);
		$arr = $this->db_fetch_all($res,0,$record_count);
		 $this->db_free_result($res);
	 return $arr;
	}
	
	/**
	* Execute Select Query and Return the result in the array format
	* @param string $sql 
	* @param integer $record_count(byReference)
	* @return array
	*/ 
	function db_ExecSingleQry($sql){
	  	 $arr = array();
		 $res =	$this->db_query($sql);
		 $arr = $this->db_fetch_array($res,MYSQL_BOTH);
		 $this->db_free_result($res);
		 return $arr;
	}
	
	/**
	* Execute Scalar Query and Return the result
	* @param string $sql  
	* @return string
	*/ 
	function db_ExecScalarQry($sql){
	  $arr = $this->db_ExecSingleQry($sql);
	  return $arr[0];
	}
	
	
	/**
	* Execute and return group concat Query
	* @param string $sql
	* @param string $glue 
	* @return string
	*/
	function db_ExecGroupConcatQry($sql,$glue=','){
	 	$arr = array();
		$res =	$this->db_query($sql);
		$arr = $this->db_fetch_all($res,1);
		$this->db_free_result($res);  
		if($glue==-1) return array_filter($arr);
	 	return implode($glue,array_filter($arr));
	}
        
        public function db_real_escape_string($sa_string,$flag=true)
        {            
            if($flag){
				if(!self::isValidInput($sa_string)){
					echo "<br/>sorry request page could not found";
					exit;
				}
            }
            return mysql_real_escape_string($sa_string);               
	}
        public function isValidInput($input)
        {       
		$returnFlag = true;
		if(!is_numeric($input)){
			$blackListArr = array('truncate','sleep','drop','insert','update','delete','select','alter');
			$input = strtolower($input);
			foreach ($blackListArr as $delimiter) {
				$expldArr = explode($delimiter, $input);
				if(count($expldArr)>1){
					$returnFlag = false;
					break;
				}
			}
		}
		return $returnFlag;
	}
  	
  function db_ExecCacheSingleQry($sql,$time=3600,&$fromCache=0){
  	$sqlCacheFile = $this->cachefile.'/singlerecord-'.md5($sql).'.txt'; 
  	$arr = array();
		if (!file_exists($sqlCacheFile) || (time()-filemtime($sqlCacheFile) > $time)) { 
			 	$res =	$this->db_query($sql);
		 		$arr = $this->db_fetch_array($res,MYSQLI_BOTH);
		 		$this->db_free_result($res); 
 				file_put_contents($sqlCacheFile,serialize($arr),LOCK_EX);
	  }else{
	  	$fromCache = 1;
    	$arr=unserialize(file_get_contents($sqlCacheFile)); 
		}
	  return $arr;
	}  
  
  function db_ExecCacheScalarQry($sql,$time=3600,&$fromCache=0){
  	$sqlCacheFile = $this->cachefile.'/recordVal-'.md5($sql).'.txt'; 
  	$val = '';
		if (!file_exists($sqlCacheFile) || (time()-filemtime($sqlCacheFile) > $time)) { 
			$arr = $this->db_ExecSingleQry($sql);
			$val = $arr[0];
    	file_put_contents($sqlCacheFile,$val,LOCK_EX);
	  }else{
			$fromCache = 1;
			$val= file_get_contents($sqlCacheFile);
		}
	  return $val;
	} 
  	
  function db_ExecCacheQry($sql,$time=3600,&$fromCache=0){ 
  	$sqlCacheFile = $this->cachefile.'/recordset-'.md5($sql).'.txt'; 
  	$arr = array();
		if (!file_exists($sqlCacheFile) || (time()-filemtime($sqlCacheFile) > $time)) { 
    	// Save to cache  
		 	$res =	$this->db_query($sql);
		 	$arr = $this->db_fetch_all($res,0,$record_count);
		 	$this->db_free_result($res);
    	file_put_contents($sqlCacheFile,serialize($arr),LOCK_EX);
    }else{
			$fromCache = 1;
    	// Retrieve from cache
    	$arr=unserialize(file_get_contents($sqlCacheFile));
		}
		return $arr;
	}
	
	function db_ExecCacheGroupConcatQry($sql,$glue=',',$time=3600,&$fromCache=0){ 
  	$sqlCacheFile = $this->cachefile.'/groupconcat-'.md5($sql).'.txt'; 
  	$arr = array();
		if (!file_exists($sqlCacheFile) || (time()-filemtime($sqlCacheFile) > $time)) { 
    	// Save to cache   
				$res =	$this->db_query($sql);
				$arr = $this->db_fetch_all($res,1);
				$this->db_free_result($res); 
    	file_put_contents($sqlCacheFile,serialize($arr),LOCK_EX);
    }else{
			
    	// Retrieve from cache
			$fromCache = 1;
    	$arr=unserialize(file_get_contents($sqlCacheFile));
		}
		if($glue ==-1)  return $arr;
		return implode($glue,array_filter($arr));    
	}
  	
  
}
?>