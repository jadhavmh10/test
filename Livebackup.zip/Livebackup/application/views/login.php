
<script>
    $(document).ready(function () {
        $('#login').validate({
            rules: {
                uname: {
                    required: true,
                    remote: {
//                        url: 'http://localhost/adityagold/chk-username',
                        url: '<?php echo base_url(); ?>index.php/chkusername',
                        method: 'post'
                    }
                },
                password: {
                    required: true,
                    remote: {
//                        url: 'http://localhost/adityagold/chk-password',
                        url: '<?php echo base_url(); ?>index.php/chkpassword',
                        method: 'post'
                    }
                }
            },
            messages: {
                uname: {
                    required: "Please Enter User name.",
                    remote: "Please Enter valid user name"
                },
                password: {
                    required: "Please Enter Password.",
                    remote: "Please Enter valid password."
                }
            }
        });
    });

</script>
 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<div class="container">
    <div class="card card-container">
        <!-- <img class="profile-img-card" src="//lh3.googleusercontent.com/-6V8xOA6M7BA/AAAAAAAAAAI/AAAAAAAAAAA/rzlHcD0KYwo/photo.jpg?sz=120" alt="" /> -->
        <img id="profile-img" class="profile-img-card" src="//ssl.gstatic.com/accounts/ui/avatar_2x.png" />
        <p id="profile-name" class="profile-name-card"></p>
        <form  id="login" method="post"  class="form-signin">
            <span id="reauth-email" class="reauth-email"></span>
            <input type="text" id="uname" name="uname" class="form-control" placeholder="Email address" required autofocus>
            <input type="password"  name="password" id="inputPassword" class="form-control" placeholder="Password" required>
            <div id="remember" class="checkbox">
                <label>
                    <input type="checkbox" value="remember-me"> Remember me
                </label>
            </div>
            <button class="btn btn-lg btn-primary btn-block btn-signin" type="submit">Sign in</button>
        </form><!-- /form -->
        <a href="#" class="forgot-password">
            Forgot the password?
        </a>
    </div>
</div>