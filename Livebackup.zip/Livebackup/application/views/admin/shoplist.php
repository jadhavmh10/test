<!DOCTYPE html>



<html lang="en">
    <body>

        <div id="wrapper">
            <!----------------------------------------Start Header----------------------------------->
            <?php $this->load->view("admin/header"); ?>
            <!--------------------------------------End Header----------------------------------->
            <div id="page-wrapper">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 class="page-header">Business List</h3>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">

                    <div class="">

                        <table id="example" class="table table-striped table-bordered" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Shop Code</th>
                                    <th>Shop Name</th>
                                    <th>Shop Type</th>
                                    <th>Date</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php
                                foreach ($shoplist as $val) { ?>
                                  
                                <tr>
                                    <td><?php  echo  $val['id'];?></td>
                                    <td><?php echo $val['shop_name'];  ?></td>
                                    <td><?php echo $val['shop_code']; ?></td>
                                    <td><?php echo $val['shop_type']; ?></td>
                                    <td><?php   echo  date("d-m-Y", strtotime($val['db_add_date'])); ?></td>
                                    <td><a href="#">Close Shop</a></td>

                                </tr>
                                
                              <?php } ?>
                                
                            </tbody>
                            <tfoot>
                                
                            </tfoot>
                        </table>

                    </div>
                </div>
            </div>
        </div>
        <!-- /#wrapper -->

        <!-----------------------------------Start Footer-------------------------------->
        <?php $this->load->view("admin/footer"); ?>

        <!-------------------------------------End Footer-------------------------------------->
    </body>

</html>

<script>
    $(document).ready(function () {
        $('#example').DataTable();
    });

    $(document).ready(function () {
        $('#addshop').validate({
            rules: {
                shopcode: {
                    required: true
                },
                shopname: {
                    required: true
                },
                shoptype: {
                    required: true
                }
            },
            messages: {
                shopcode: {
                    required: "Please Enter shopcode name."
                },
                shopname: {
                    required: "Please Enter shop name."
                },
                shoptype: {
                    required: "Please Enter shop Type."
                }
            }
        });
    });

</script>
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>