<?php

class Home extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model("common_model");
    }

    public function index(){
         $this->load->view("index");
    }
    
    public function ins_master() {
        $datanumrows = $this->common_model->ins_master("emp", array('salary' => 1234321));
    }

    public function showuser($offset = 0) {
        $data = array();
        $data['userinfo'] = $this->common_model->getrecoreds("registration", array(), '', 5, $offset);
        $datanumrows = $this->common_model->getnumrows("registration");
        $this->load->library('pagination');

        $config['base_url'] = 'http://localhost/democode/index.php/showuser1/';
        $config['total_rows'] = $datanumrows;
        $config['per_page'] = 5;

        $this->pagination->initialize($config);

        echo $this->pagination->create_links();

        $this->load->view("show", $data);
    }

    public function home() {
        
        die("exe");
        $this->load->view("includes/header");
        $this->load->view("login");
        $this->load->view("registration");
        $this->load->view("includes/footer");
    }

    public function register() {
        $name = $this->input->post('name');
        $email = $this->input->post('email');
        $adderss = $this->input->post('address');
        $phno = $this->input->post('phno');
        if ($email != '' && $phno != '' && $adderss != '' && $phno != '') {
            $insertArray = array('name' => $name, 'email' => $email, 'address' => $adderss, 'phno' => $phno);
            $insertid = $data = $this->common_model->insertblog("registration", $insertArray);
            print_r($insertid);
        }
    }

    public function chkusername() {

        $data = $this->common_model->getrecoreds("login", array('username'), array('username' => $this->input->post('uname')));
        if (count($data) > 0) {
            echo "true";
        } else {
            echo "false";
        }
    }

    public function chkpass() {

        $passdata = $this->common_model->getrecoreds("login", array('password'), array('password' => $this->input->post('psw')));
        if (count($passdata) > 0) {
            echo "true";
        } else {
            echo "false";
        }
    }

}

?>
