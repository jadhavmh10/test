<?php

class Login extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    public function logout() {
        $chkuname = $this->session->userdata('uname');
        if (!empty($chkuname)) {
            $chkuname = $this->session->unset_userdata('uname');
        }
        redirect(base_url());
    }

    public function index() {
        if (!empty($this->input->post('password')) && !empty($this->input->post('uname'))) {
            $logdata = array(
                'uname' => $this->input->post('uname'),
                'password' => $this->input->post('password'),
                'logged_in' => TRUE
            );
            $this->session->set_userdata('uname', $this->input->post('uname'));
            redirect('admin');
        }
        $this->load->view("includes/header");
        $this->load->view("login");
    }

    public function chkusername() {
        $data = $this->common_model->getrecoreds("user", array('username'), array('username' => $this->input->post('uname')), '', '', '');
        if (count($data) > 0) {
            echo "true";
        } else {
            echo "false";
        }
    }

    public function chkpass() {
        $passdata = $this->common_model->getrecoreds("user", array('password'), array('password' => $this->input->post('password')), '', '', '');
        if (count($passdata) > 0) {
            echo "true";
        } else {
            echo "false";
        }
    }

}

?>
