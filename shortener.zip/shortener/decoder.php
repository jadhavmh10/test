<?php

$con = mysqli_connect("localhost", "root", "");
if (!$con) {
    die('Could not connect: ' . mysql_error());
}
$con->select_db("demo");

$de = $_GET["decode"];

$result = $con->query("select * from shortened where shortened='$de'");

while ($row = mysqli_fetch_array($result)) {
    $res = $row['url'];
    header("location:" ."http://".$res);
}
?>  