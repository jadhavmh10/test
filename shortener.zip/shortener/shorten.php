<?php

$con = mysqli_connect("localhost", "root", "");
if (!$con) {
    die('Could not connect: ' . mysql_error());
}

$con->select_db('demo');
$urlinput = ($_POST['url']);
$id = rand(10000, 99999);
$shorturl = base_convert($id, 20, 36);
$sql = "insert into shortened values('$id','$urlinput','$shorturl')";
$con->query($sql);
//echo "Shortened url is: http://Bitly.com/" . $shorturl . "";
echo "Shortened url is http://localhost/shortener/". $shorturl ."";  
$con->close();
?>  