<?php
include_once('../vendor/autoload.php');
use \Firebase\JWT\JWT;

$key = "82148d5fa5bb43f59b189504562e729d"; // development - 9991650  & stag as well
//$key = "4c5a1e23050a428198f940b38d3e3caa"; // production - 9991651

//POST
$payloadCreateUser = [      
		"id" => 'stevemartin146.sa@gmail.com',
		"email" => 'stevemartin146.sa@gmail.com',
		"firstName" => 'Test',
		"lastName" => 'User',
		"optInStatus" => 'YES',
		"status" => 'ACTIVE',
		"phone" => '1234567890',
		"birthDate" => '2000-05-11',
		"anniversaryDate" => '2018-05-11'
		  ];
//PATCH
$payloadUpdateUser = [      
		"id" => 'stevemartin144.sa@gmail.com',
		//"email" => 'stevemartin145.sa@gmail.com',
		//"firstName" => 'Test 1',
		//"lastName" => 'User 1',
		"optInStatus" => 'YES'
		//"status" => 'ACTIVE',
		//"phone" => '1234567892',
		//"birthDate" => '2001-05-11',
		//"anniversaryDate" => '2017-05-11'
		  ];

//Order post
$payloadOrder = [      
  "id" => "SATESTORDER05",
  "userId" => "stevemartin05.sa@gmail.com",
  "email" => "stevemartin05.sa@gmail.com",
   "orderTotal"=>"96.46",
  /*"firstName" => "John",
  "lastName" => "Doe",
  "eventId" => "4",
  "coupon" => ["SATEST","SATEST2"],*/
  "orderDetail" => [
   [
    "id" => "CD971AN#140",
    "quantity" => 1,
    "unitPrice" => 82.99,
    "estimatedShipDate" => "08/27/18"
    /*"categoryId" => "C1",
    "categoryName" => "flowers",
    "url" => "domain.com/image.gif",
    "imageUrl" => "domain.com/image.gif",
    "description" => "XYZ Flowers" */
   ],
   [
    "id" => "CB324WN#140",
    "quantity" => 1,
    "unitPrice" => 10.00,
   "estimatedShipDate" => "08/27/18"
     /*"categoryId" => "C1",
    "categoryName" => "flowers",
    "url" => "domain.com/image.gif",
    "imageUrl" => "domain.com/image.gif",
    "description" => "XYZ Flowers"*/ 
   ]
  ]
  
 ];

// "coupon" => ["SARL0RXQ12017","SAZRLJ8Q12017"],
// "coupon" => "SAZRLJ8Q12017",

//GET*/
$payloadGetUser = 'stevemartin144.sa@gmail.com';

$payload = $payloadOrder; //$payloadGetUser, $payloadCreateUser, $payloadUpdateUser, $payloadOrder

$payload = json_encode($payload);

echo '<br> json='.$payload;
$payload = base64_encode($payload);
echo '<br> payload = '.$payload;
$hmac= base64_encode(hash_hmac('sha256',$payload, $key, true));
echo '<br> hmac = '.$hmac;


$token = array(
    "sub" => "HP",
    "exp" => time()+3600,
    "site_id" => 9991650,
    "hmac" => $hmac
);


echo "<br>payload : <br>".json_encode($token);
$jwt = JWT::encode($token, $key);
/*$head = [      
		"typ" => 'JWT',
		"alg" => 'HS256'
		  ];
$jwt = JWT::encode($token, $key, 'HS256', null, $head);
*/
echo "<br>Token : <br>".$jwt;
$decoded = JWT::decode($jwt, $key, array('HS256'));
echo "<br>";
print_r($decoded);
/*$key = 'abc';
$explode = explode('.',$jwt);
$explode[2] = '';
$dec = json_decode(base64_decode($explode[0]),true);
$dec['alg']='none';
$dec = json_encode($dec);
echo $dec;
$dec = base64_encode($dec);
$explode[0] = $dec;
$implode = implode('.',$explode);
$jwt = $implode;*/
//$key = "ogwcmi0UkBJwbhEHkAhW";
//$key = base64_encode($key);
/*$jwt = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJIUCIsInNpdGVfaWQiOiI5OTkxNjUwIiwiZXhwIjoiMTUyODI4MjQ1NzY4NiIsImhtYWMiOiJBS1JjVjZnL0d6QlZkRVVnMURuZ0c5MFVzVDhzbGphRzIvSlhYemMvekpNPSJ9.e9c3_JOWQT2MzOjk0uBbVP4xyBr_Opg8rLy3jcAmVCM";

echo "<br>Client Token : <br>".$jwt;

$decoded = JWT::decode($jwt, $key, array('HS256'));
echo "<br>";
print_r($decoded);
$payload = '{"id":"user@domain.com"}';
$payload = base64_encode($payload);
$hmac= base64_encode(hash_hmac('sha256',$payload, $key, true));
echo '<br>Hmac = '.$hmac;*/

?>