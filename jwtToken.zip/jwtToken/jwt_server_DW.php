<?php

include_once('E:\xampp\htdocs\jwtToken\vendor\autoload.php');

use \Firebase\JWT\JWT;

echo $currentDate = 1.543272502569E12;

echo date('Y-m-d H:i:s', $currentDate);

echo "</bre>";
$key = "ebFFH74bpvBIfzr4WlVjfJxCXTEkMq1Q";

$payloadOrder = [
    "iss" => "abc",
    "name" => "Deepak",
    "lastname" => "Mulik"
];

$payload = "mqa001";

$payload = json_encode($payload);

echo '<br> json=' . $payload;
$payload = base64_encode($payload);
echo '<br> payload = ' . $payload;
$hmac = base64_encode(hash_hmac('sha256', $payload, $key, true));
echo '<br> hmac = ' . $hmac;


$token = array(
    "sub" => "HP",
    "exp" => time() + 3600,
    "site_id" => 9809090, //9991650,9991680
    "hmac" => $hmac
);



echo "<br>payload : <br>" . json_encode($token);
$jwt = JWT::encode($token, $key);
/* $head = [      
  "typ" => 'JWT',
  "alg" => 'HS256'
  ];
  $jwt = JWT::encode($token, $key, 'HS256', null, $head);
 */
echo "<br>Token : <br>" . $jwt;

echo "<br><br>";
$decoded = JWT::decode($jwt, $key, array('HS256'));
echo "<br>";
print_r($decoded);
?>