


<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Headers: Content-Type, Credentials, Authorization, *');

include_once("jwtToken/vendor/autoload.php");

use \Firebase\JWT\JWT;
$key = "82148d5fa5bb43f59b189504562e729d";


if(isset($_REQUEST['gn'])==1){
    $payloadUser = [      
		"userid" => '1',
		"email" => 'rahuljadhav@gmail.com',//$email,
	
		  ];
$payload = json_encode($payloadUser);
$hmac= base64_encode(hash_hmac('sha256',$payload, $key, true));
$token = array(
    "sub" => "ClientSignin",
    "exp" => time()+3600,
    "email" =>'rahul@gmail.com', //$email,
    "userid" => '1',//$id,
    "hmac" => $hmac
);

$jwt = JWT::encode($token, $key);
echo "jwt==>".  $jwt;

}


if(isset($_REQUEST['decode'])==1){

    $tk=$_REQUEST['tk'];
    echo "<br><br><br><br>";
    $decoded = JWT::decode($tk, $key, array('HS256'));
    echo "decoded==>";
    print_r($decoded);
        
}

?>