
<?php

include_once("jwtToken/vendor/autoload.php");
include_once 'db-connection.php';
use \Firebase\JWT\JWT;


class Usercontroller {
    private $dbobj;
    public function __construct($request) {
        $this->SetHeaders();
        $this->dbobj = new database(DB_BLOG);
        if (!($this->dbobj->db_connect())) {
            die("connect failed");
        }
        $this->Init($request);
    }

    public function Init($requestBody) {
        $action = $_REQUEST['action'];
        switch ($action) {
            case 'registerUser':
                $this->registerUser();
                break;

            case 'getUserList':
                $this->getUserList();
                break;

            case 'getUserDetail':
            $this->getUserDetail();
              break;
case 'updateUserProfile':
$this->updateUserProfile();
break;



case 'userSignIn':
$this->userSignIn();
break;

              default:
                self::response('0', array('error' => "Invalid action provided"));
        }
    }

    public function registerUser() {
        $profilefor = $_REQUEST['profilefor'];
        $fname = $_REQUEST['name'];
        $gender = $_REQUEST['gender'];
        $dob = $_REQUEST['dob'];
        $phone = $_REQUEST['phone'];
        $email = $_REQUEST['email'];
        $password = $_REQUEST['password'];
        $religion = $_REQUEST['religion'];

        if (!empty($profilefor) && !empty($fname) && !empty($gender) && !empty($dob)) {
            $result = $this->dbobj->db_query("INSERT INTO `user`(`profilefor`, `first_name`, `dob`, `email`,  `phone`, `password`, `gender`, religion) VALUES ('$profilefor','$fname','$dob','$email' ,'$phone','$password','$gender', '$religion')");
            if ($result > 0) {
                $lastInsertId = $this->dbobj->db_insert_id();
                if ($lastInsertId > 0) {
                    return self::response('1', array('lastId' => $lastInsertId));
                } else {
                    self::response('0', array('error' => "Some thing went wrong"));
                }
            }
        }
    }

    public function getUserList() {
        $gender = (isset($_REQUEST['gender']))?$_REQUEST['gender']:'';
        if($gender!=''){
            $userListArray = $this->dbobj->db_ExecQry("SELECT id, `first_name`, `dob`, education,height, `religion`, `db_add_date` , `height` FROM `user` WHERE  `gender`=$gender");
            $userlistcnt = $this->dbobj->db_ExecScalarQry("SELECT count(*) as count FROM `user` WHERE `gender`=$gender");
                
                
            if (count($userListArray) > 0) {
                return self::response('1', array('userlist' => $userListArray,'totalcnt'=>$userlistcnt));
            }
        }
       
    }


    function validateAuthToken($authToken){
        $key = '82148d5fa5bb43f59b189504562e729d';
        $decodedArray = array();
        try {
            $decoded = JWT::decode($authToken, $key, array('HS256'));
            $decodedArray['status']=1;
            $decodedArray['jwt']=$decoded;
            return  $decodedArray;
        } catch (\Firebase\JWT\ExpiredException $e) {
            $responseArray = array();
            $object = new stdClass();
            $tokenError = $e->getMessage();
            $responseArray['error'] = $tokenError;
            $responseArray['status'] = 0;
            $object = json_decode(json_encode($responseArray), FALSE);
            return $responseArray;
        }
    }
    


    public function getUserDetail() {
$authToken= self::getAuthToken();
if($authToken!=''){
$validateToken=self::validateAuthToken($authToken);

if($validateToken['status']==1){
    $jwt=$validateToken['jwt'];
   $uid = $jwt->userid;
    $userDetailArray = $this->dbobj->db_ExecQry("SELECT * FROM `user` WHERE  `id`=$uid");
     self::response('1', array('userDetail' => $userDetailArray[0]));

}else{
    self::response('201', array('error' =>"token expired please login"));  
}
    }
    }



public function generateJwtToken($user_id,$email){
    if($user_id!='' && $email!=''){
    $key = "82148d5fa5bb43f59b189504562e729d";
    $payloadUser = [      
		"userid" => $user_id,
		"email" =>$email,
		  ];
$payload = json_encode($payloadUser);
$hmac= base64_encode(hash_hmac('sha256',$payload, $key, true));
$token = array(
    "sub" => "ClientSignin",
    "exp" => time()+3600,
    "email" =>$email,
    "userid" => $user_id,
    "hmac" => $hmac
);

 $jwt = JWT::encode($token, $key);

 return $jwt;
}else{
    
        return 0;
    }
}




function getAuthToken() {
    $headerData = getallheaders();
    $header = '';
    if (!empty($headerData['Authorization'])) {
        if (preg_match('/Bearer\s(\S+)/', $headerData['Authorization'], $matches)) {
            $header = $matches[1];
        } else {
            $header = '';
        }
    }
    return $header;
}




public function userSignIn(){
    $email=(isset($_REQUEST['email']))?$_REQUEST['email']:'';
    $password=(isset($_REQUEST['password']))?$_REQUEST['password']:'';

if(!empty($email) && !empty($password)){
    $userLoginArray = $this->dbobj->db_ExecQry("SELECT id , email, password FROM `user` WHERE email='$email' AND password='$password' ");
    if(!empty($userLoginArray)){
   
$jwt= self::generateJwtToken($userLoginArray[0]['id'],$userLoginArray[0]['email']);

if($jwt)
{
    $userinfo=array('id'=>$userLoginArray[0]['id'],'email'=>$userLoginArray[0]['email'],'token'=>$jwt);
    self::response('1', array('userinfo' =>$userinfo));
}else{
    self::response('0', array('error' =>"Something wend wrong"));
}   
    }else{
        self::response('0', array('error' =>"Your email and password is invalid"));
    }
    
}else{
     self::response('0', array('error' =>'Invalid parameters'));
}
}

    public function updateUserProfile(){

  $email=(isset($_REQUEST['email']))?$_REQUEST['email']:'';
  $first_name=(isset($_REQUEST['first_name']))?$_REQUEST['first_name']:'';
  $middle_name=(isset($_REQUEST['middle_name']))?$_REQUEST['middle_name']:'';
  $last_name=(isset($_REQUEST['last_name']))?$_REQUEST['last_name']:'';
  $profilefor=(isset($_REQUEST['profilefor']))?$_REQUEST['profilefor']:'';
  $phone=(isset($_REQUEST['phone']))?$_REQUEST['phone']:'';
 $id=(isset($_REQUEST['id']))?$_REQUEST['id']:'';
$base_name="";

if(isset($_FILES['profile_img'])){
    if(move_uploaded_file($_FILES['profile_img']['tmp_name'], 'upload/'. $_FILES["profile_img"]['name'])){
        $base_name=$_FILES["profile_img"]['name'];
    }
}else{
    $base_name=(isset($_REQUEST['profile_img_path']))?$_REQUEST['profile_img_path']:'';
}


$profileimg=($base_name!='')? "profile=". "'$base_name'" . ' '.',':'';


  $result = $this->dbobj->db_query("UPDATE `user`  SET $profileimg  profilefor='$profilefor' , first_name='$first_name' , middle_name='$middle_name' , last_name='$last_name'  , email='$email', phone=$phone WHERE id=$id");
if ($result > 0) {
    $responseData=array('email'=>$email,'first_name'=>$first_name,'middle_name'=>$middle_name,'last_name'=>$last_name,
'profile_for'=>$profilefor,'phone'=>$phone,'profile'=>$base_name,'id'=>$id);

    self::response('1', array('userUpdatedData'=>$responseData));
    }else {
        self::response('0', array('error' => "Some thing went wrong"));
    }
    }

    public function response($status, $dataArray = array()) {

        $responseBody = array();
        $responseBody['status'] = $status;
        $responseBody['data'] = $dataArray;
        echo json_encode($responseBody);
        exit(0);
    }


    public function SetHeaders() {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Allow-Headers: Content-Type, Credentials, Authorization, *');
    }

    public function CallAPI($method, $url, $data) {
        $curl = curl_init();
        switch ($method) {
            case "POST":
                curl_setopt($curl, CURLOPT_POST, 1);
                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            case "PUT":
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            default:
                if ($data)
                    $url = sprintf("%s?%s", $url, http_build_query($data));
        }

        // OPTIONS:
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'APIKEY: 111111111111111111111',
            'Content-Type: application/json',
        ));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);

        // EXECUTE:
        $result = curl_exec($curl);
        if (!$result) {
            die("Connection Failure");
        }
        curl_close($curl);
        return $result;
    }

}

$UsercontrollerObj = new Usercontroller($_REQUEST);
?>
 
