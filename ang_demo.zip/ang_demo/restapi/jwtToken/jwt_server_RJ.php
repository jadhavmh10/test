 
<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Headers: Content-Type, Credentials, Authorization, *');

include_once('E:\xampp\htdocs\jwtToken\vendor\autoload.php');
error_reporting(0);

use \Firebase\JWT\JWT;

$key = $_REQUEST['key'];
$siteid = $_REQUEST['siteid'];
$alg = $_REQUEST['alg']; //sha256
$payload = $_REQUEST['payload'];
$payload = json_encode($payload);


//if (!empty($key) && !empty($siteid) && !empty($alg) && !empty($payload)) {
//
//    echo "key==>" . $key . "<br>";
//    echo "siteid==>" . $siteid . "<br>";
//    echo "alg==>" . $alg . "<br>";
//    echo "payload==>" . $payload . "<br>";
//  
//}

  

$responseArray = array();
if (!empty($key) && !empty($siteid) && !empty($alg) && !empty($payload)) {
   
//echo '<br> json=' . $payload;
    $payload = base64_encode($payload);
//echo '<br> payload = ' . $payload;
    $hmac = base64_encode(hash_hmac($alg, $payload, $key, true));
//echo '<br> hmac = ' . $hmac;


    $token = array(
        "sub" => "ClientSign",
        "exp" => time() + 3600,
        "site_id" => $siteid,
        "hmac" => $hmac
    );


 
//echo "<br>payload : <br>" . json_encode($token);
    $jwt = JWT::encode($token, $key);
    
    $responseArray['status'] = 1;
    $responseArray['jwt'] = $jwt;
    echo json_encode($responseArray);
    exit(0);

//echo "<br><br>";
//$decoded = JWT::decode($jwt, $key, array('HS256'));
//echo "<br>";
//print_r($decoded);
} else {
    $responseArray['status'] = 0;
    $responseArray['message'] = 'Invalid parametrs Provided';
    echo json_encode($responseArray);
    exit(0);
}
?>

<script>
//    var payload = {};
//    payload['s22SiteId'] = 9411181;
//    payload['offset'] = 0;
//    payload['limit'] = 16;
//    payload['s22SaPage'] = 1;
//    payload['s22SearchParam'] = 0;
//    payload['s22SearchValue'] = 0;
//
//    $.ajax({
//        type: 'POST',
//        url: "http://localhost/jwtToken/jwt_server_RJ.php",
//        data: {'key': 'RVY1MEFfT09GN0w0NVYwVldGR1VQQ00xTTlLUkpNTlZIUzI1Ng==', 'site_id': 9411181, 'data': 'sadasdasdasdasd', 'alg': 'sha256', 'payload': JSON.stringify(payload)},
//        dataType: "text",
//        success: function (resultData) {
//            alert("Save Complete")
//
//            console.log(JSON.parse(resultData));
//        }
//    });
</script>