$(document).ready(function () {
    $(function () {
        $('#dob').datetimepicker();

    });
});