import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../../_services/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { $$ } from 'protractor';
import { AuthenticationServiceService } from '../../_services/authentication-service.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})

export class SigninComponent implements OnInit {
  userdataArray: any = [];
  @ViewChild('modalcloseBtn') closeBtn: ElementRef;
  constructor(private authService: AuthenticationServiceService, private userService: UserService, private router: Router, private activateRoute: ActivatedRoute) { }

  ngOnInit() {

  }

  userSignin(userdata: NgForm) {
    if (userdata.submitted) {

      const userformData = new FormData();
      userformData.append('email', userdata.form.value.email);
      userformData.append('password', userdata.form.value.password);

      this.userService.userSignIn(userformData).subscribe(
        (responseData) => {
          console.log(responseData);
          this.userdataArray = responseData;
          if (responseData['data']['userinfo']['token'] != '' && responseData['status'] == 1) {
            this.authService.setAuthToken(responseData['data']['userinfo']['token']);
            this.closeBtn.nativeElement.click();
            this.router.navigate(['/profile-setting']);
          }
        },
        (error) => {
          alert(JSON.stringify(error));
        }
      );
    }
  }
}
