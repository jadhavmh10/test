import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './core/header/header.component';
import { FooterComponent } from './core/footer/footer.component';
import { CoreComponent } from './core/core.component';
import { SignupComponent } from './auth/signup/signup.component';
import { SigninComponent } from './auth/signin/signin.component';
import { AboutUsComponent } from './home/pages/about-us/about-us.component';
import { ContactUsComponent } from './home/pages/contact-us/contact-us.component';
import { SearchComponent } from './home/pages/search/search.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { BridesComponent } from './home/pages/profile/brides/brides.component';
import { GroomsComponent } from './home/pages/profile/grooms/grooms.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { ProfilesettingComponent } from './featured/profilesetting/profilesetting.component';
import { ProfiledetailComponent } from './featured/profiledetail/profiledetail.component';
import { JwtInterceptor } from './_helpers/jwt.interceptor';
import { ErrorInterceptor } from './_helpers/error.interceptor';
// import {FakeBackendInterceptor } from './_helpers/fake-backend';
 
 
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    CoreComponent,
    SignupComponent,
    SigninComponent,
    AboutUsComponent,
    ContactUsComponent,
    SearchComponent,
    BridesComponent,
    GroomsComponent,
    ProfilesettingComponent,
    ProfiledetailComponent,
    
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    NgxPaginationModule
    


  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
