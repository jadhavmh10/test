import { Component, OnInit } from '@angular/core';
import { AuthenticationServiceService } from '../../_services/authentication-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  constructor(private userAuth: AuthenticationServiceService,private router:Router) { }

  isLogin = false;
  ngOnInit() {

    this.userAuth.userActivated.subscribe(
      (id) => {
        if (id == 1) {
          alert("id" + id);
          this.isLogin = true;
        } else {
          this.isLogin = false;
        }
      }
    );

  }

  signout() {
    this.router.navigate(['/home']);
    this.userAuth.clearAuthToken();

  }

}
