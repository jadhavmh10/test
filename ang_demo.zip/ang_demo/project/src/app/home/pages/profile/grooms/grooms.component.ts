import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../../_services/user.service';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-grooms',
  templateUrl: './grooms.component.html',
  styleUrls: ['./grooms.component.css']
})
export class GroomsComponent implements OnInit {
  GroomresponseArray = '';
  config: any;
  totalcnt: 0;

  constructor(private userService: UserService, private route: ActivatedRoute, private router: Router) {
    this.config = {
      currentPage: 1,
      itemsPerPage: 2,

    };
    this.route.queryParamMap
      .map(params => params.get('page'))
      .subscribe(page => this.config.currentPage = page);
  }

  ngOnInit() {
    this.userService.getUserList(1).subscribe(
      (responseArray) => {
        if (responseArray['status'] == 1) {
          this.totalcnt = responseArray['data']['totalcnt'];
          this.GroomresponseArray = responseArray['data']['userlist'];
          console.log(this.GroomresponseArray);
          this.config.totalItems = +this.totalcnt;
        }
      }
    )
  }
  pageChange(newPage: number) {
    this.router.navigate(['/grooms'], { queryParams: { page: newPage } });
  }


}
