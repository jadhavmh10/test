import { Injectable, OnInit } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationServiceService implements OnInit {
  userActivated = new Subject();

  constructor() {
  }
  ngOnInit() {

  }

  setAuthToken(token) {
    this.userActivated.next(1);
    localStorage.setItem('auth_token', token);
  }

  getAuthToken() {
    return localStorage.getItem('auth_token');
  }

  clearAuthToken() {
    this.userActivated.next(0);
    localStorage.removeItem('auth_token');
  }

}
