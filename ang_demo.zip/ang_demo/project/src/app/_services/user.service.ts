import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpClient: HttpClient) { }

  userSignup(userdata) {
    console.log(userdata);
    const userFormData = new FormData();
    for (let key in userdata) {
      userFormData.append(key, userdata[key]);
    }

    return this.httpClient.post("http://localhost/restapi/user?action=registerUser", userFormData)
      .pipe(

      );
  }

  getUserList(gender) {
    return this.httpClient.get("http://localhost/restapi/user?action=getUserList&gender=" + gender);
  }

  userSignIn(userdata) {
    return this.httpClient.post("http://localhost/restapi/user?action=userSignIn",userdata);
  }



}
