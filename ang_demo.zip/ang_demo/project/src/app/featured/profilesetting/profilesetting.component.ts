import { Component, OnInit, ViewChild } from '@angular/core';
import { UserService } from 'src1/app/_services/user.service';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationServiceService } from '../../_services/authentication-service.service';
// import { setInterval } from 'timers';

@Component({
  selector: 'app-profilesetting',
  templateUrl: './profilesetting.component.html',
  styleUrls: ['./profilesetting.component.css']
})
export class ProfilesettingComponent implements OnInit {
  status = 2;
  file = "";
  isdisabled = true;
  profile_response: any = [];
  @ViewChild('f') userForm: NgForm;
  constructor(private userService: UserService, private authService: AuthenticationServiceService, private router: Router) { }

  ngOnInit() {
    this.userService.getuserdetail()
      .subscribe(
        (response) => {
          if (response['status'] == 1) {
            this.profile_response = response['data']['userDetail'];
            this.userForm.form.patchValue(
              {
                fname: response['data']['userDetail']['first_name'],
                mname: response['data']['userDetail']['middle_name'],
                lname: response['data']['userDetail']['last_name'],
                profilefor: response['data']['userDetail']['profilefor'],
                email: response['data']['userDetail']['email'],
                phone: response['data']['userDetail']['phone'],
                hiddenProfile: response['data']['userDetail']['profile']
              }
            );
          } else {
            this.authService.clearAuthToken();
            this.router.navigate(['/']);
          }
        },
        (error) => {
          alert("error in profile setting" + error);
        }
      );

  }


  profileEnable() {
    this.isdisabled = false;
  }
  updatesUserProfile() {
    console.log(this.userForm.form.value);
    const updateFormData = new FormData();
    updateFormData.append('id', '1');
    updateFormData.append('email', this.userForm.form.value.email);
    updateFormData.append('first_name', this.userForm.form.value.fname);
    updateFormData.append('middle_name', this.userForm.form.value.mname);
    updateFormData.append('last_name', this.userForm.form.value.lname);
    updateFormData.append('profilefor', this.userForm.form.value.profilefor);
    updateFormData.append('phone', this.userForm.form.value.phone);
    if (this.file != '') {

      updateFormData.append('profile_img', this.file);
    } else {
      updateFormData.append('profile_img_path', this.userForm.form.value.hiddenProfile);
    }

    this.userService.updateUserProfile(updateFormData).subscribe(
      (response) => {
        this.status = response['status'];
        this.file = "";    // this.userForm.form.value.profileimg = "";
        this.profile_response = response['data']['userUpdatedData'];
        setTimeout(() => {
          this.status = 2;
        }, 2000);

      },
      (error) => {
        alert(error);
      }
    );

    this.isdisabled = true;
  }

  updateprofile(event) {
    this.file = event.target.files[0]
  }
}
