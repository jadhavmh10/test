
<?php
include_once 'db-connection.php';


$obj = new database(DB_BLOG);
if (!($obj->db_connect())) {
    die("connect failed");
}

if (isset($_POST['loginsubmit'])) {

    $_SESSION['username'] = $_POST['username'];
    $username = $_POST['username'];
    $UserRolesQuery = "SELECT r.id,r.rolename,u.email from roles r INNER JOIN userroles ur on r.id=ur.userroleid INNER JOIN user u on u.id=ur.userid WHERE u.email='$username'";

    $result = $obj->db_query($UserRolesQuery);
    $dataArray = $obj->db_fetch_all($result);

    $permission = '';
    foreach ($dataArray as $dataVal) {
        if ($dataVal['rolename'] == 'read') {
            $permission .= 1;
        } elseif ($dataVal['rolename'] == 'write') {
            $permission .= 2;
        } elseif ($dataVal['rolename'] == 'edit') {
            $permission .= 3;
        }
    }

    $_SESSION['permission'] = $permission;
    switch ($permission) {
        case 213:
            header('Location: http://localhost/blogdemo/admin-dashboard.php');
            break;
        case 1:
            die("read");
            break;
        case 2:
            die("write");
            break;
        case 3:
            die("edit");
            break;
    }
   
}

if (!empty($_POST['username'])) {

    $email = $_POST['username'];
    $result = $obj->db_ExecScalarQry("SELECT email from user WHERE email='$email'");
    if ($result != '') {
        echo "true";
    } else {
        echo "false";
    }
    die();
}
if (!empty($_POST['password'])) {
    $password = $_POST['password'];
    $result = $obj->db_ExecScalarQry("SELECT password from user WHERE 	password='$password'");
    if ($result != '') {
        echo "true";
    } else {
        echo "false";
    }
    die();
}
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">







<!------ Include the above in your HEAD tag ---------->

<div class="container">    
    <div id="loginbox" style="margin-top:50px;" class="mainbox col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">                    
        <div class="panel panel-info" >
            <div class="panel-heading">
                <div class="panel-title">Sign In</div>
                <!--<div style="float:right; font-size: 80%; position: relative; top:-10px"><a href="#">Forgot password?</a></div>-->
            </div>     

            <div style="padding-top:30px" class="panel-body" >

                <div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>

                <form id="loginform" class="form-horizontal" role="form" method="post" action="">

                    <div style="margin-bottom: 25px" class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        <input id="login-username" type="text" class="form-control" name="username" value="" placeholder="username or email">                                        
                    </div>

                    <div style="margin-bottom: 25px" class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                        <input id="login-password" type="password" class="form-control" name="password" placeholder="password">
                    </div>



                    <div class="input-group">
                        <div class="checkbox">
                            <label>
                                <input id="login-remember" type="checkbox" name="remember" value="1"> Remember me
                            </label>
                        </div>
                    </div>


                    <div style="margin-top:10px" class="form-group">
                        <!-- Button -->

                        <div class="col-sm-12 controls">
                            <input type="submit" name="loginsubmit" value="submit" id="btn-login" href="#" class="btn btn-success">
                        </div>
                    </div>



                </form>     



            </div>                     
        </div>  
    </div>

</div>

<script>
    $(document).ready(function () {
        $('#loginform').validate({
            rules: {
                username: {
                    required: true,
                    remote: {
                        url: 'http://localhost/blogdemo/index.php',
                        method: 'post'
                    }
                },
                password: {
                    required: true,
                    remote: {
                        url: 'http://localhost/blogdemo/index.php',
                        method: 'post'
                    }
                }
            },
            messages: {
                username: {
                    required: "Please Enter User name.",
                    remote: "Please Enter valid user name"
                },
                password: {
                    required: "Please Enter Password.",
                    remote: "Please Enter valid password."
                }
            }
        });
    });

</script>