import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../../_services/user.service';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  status = 2;
  myDateValue: Date;
  constructor(private userService: UserService) { }

  ngOnInit() {
    this.myDateValue = new Date();
  }


  userSignup(userSignupData: NgForm) {
    this.userService.userSignup(userSignupData.value)
      .subscribe(
        (userResponse) => {
          this.status = userResponse['status'];
        },
        (error) => {
          this.status = 0;
          alert(JSON.stringify(error));
        },
        () => {

        }
      );
  }

  onDateChange(newDate: Date) {
    console.log(newDate);
  }

}
