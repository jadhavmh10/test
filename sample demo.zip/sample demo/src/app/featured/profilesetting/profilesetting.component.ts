import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profilesetting',
  templateUrl: './profilesetting.component.html',
  styleUrls: ['./profilesetting.component.css']
})
export class ProfilesettingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
