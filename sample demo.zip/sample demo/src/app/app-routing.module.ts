import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutUsComponent } from './home/pages/about-us/about-us.component';
import { CoreComponent } from './core/core.component';
import { SearchComponent } from './home/pages/search/search.component';
import { ContactUsComponent } from './home/pages/contact-us/contact-us.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'about-us', component: AboutUsComponent },
  { path: 'search', component: SearchComponent },
  { path: 'contact-us', component: ContactUsComponent },
  { path: 'home', component: HomeComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
