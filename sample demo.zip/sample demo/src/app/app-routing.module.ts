import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutUsComponent } from './home/pages/about-us/about-us.component';
import { CoreComponent } from './core/core.component';
import { SearchComponent } from './home/pages/search/search.component';
import { ContactUsComponent } from './home/pages/contact-us/contact-us.component';
import { BridesComponent } from './home/pages/profile/brides/brides.component';
import { GroomsComponent } from './home/pages/profile/grooms/grooms.component';
import { ProfilesettingComponent } from './featured/profilesetting/profilesetting.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'about-us', component: AboutUsComponent },
  { path: 'search', component: SearchComponent },
  { path: 'contact-us', component: ContactUsComponent },
  { path: 'home', component: HomeComponent },
  { path: 'brides', component: BridesComponent },
  { path: 'grooms', component: GroomsComponent },
  { path: 'profile-setting', component: ProfilesettingComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
