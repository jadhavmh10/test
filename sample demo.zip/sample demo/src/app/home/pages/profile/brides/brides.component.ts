import { Component, OnInit } from '@angular/core';
import { UserService } from '../../../../_services/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';


@Component({
  selector: 'app-brides',
  templateUrl: './brides.component.html',
  styleUrls: ['./brides.component.css']
})
export class BridesComponent implements OnInit {
  bridesresponseArray = "";
  config: any;
  totalcnt: 0;


  constructor(private userService: UserService, private route: ActivatedRoute, private router: Router) {
    this.config = {
      currentPage: 1,
      itemsPerPage: 2,
    };


    this.route.queryParamMap
      .map(params => params.get('page'))
      .subscribe(page => this.config.currentPage = page);

  }

  ngOnInit() {
    this.userService.getUserList(0).subscribe(
      (responseArray) => {
        if (responseArray['status'] == 1) {
          this.totalcnt = responseArray['data']['totalcnt'];
          this.bridesresponseArray = responseArray['data']['userlist'];
          console.log(this.bridesresponseArray);
          this.config.totalItems = +this.totalcnt;
        }
      }
    )
  }
  pageChange(newPage: number) {
    this.router.navigate(['/brides'], { queryParams: { page: newPage } });
  }

}
