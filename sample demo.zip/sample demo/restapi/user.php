
<?php

include_once 'db-connection.php';

class Usercontroller {

    private $dbobj;

    public function __construct($request) {
        $this->SetHeaders();
        $this->dbobj = new database(DB_BLOG);
        if (!($this->dbobj->db_connect())) {
            die("connect failed");
        }
        $this->Init($request);
    }

    public function Init($requestBody) {
        switch (isset($_REQUEST['action'])) {
            case 'registerUser':
                $this->registerUser();
                break;
            default:

                self::response('0', array('error' => "Invalid action provided"));
        }
    }

    public function registerUser() {

        try {
            $result = $this->dbobj->db_query("INSERT INTO `user`(`user_name`, `email`, `address`, `phone`) VALUES ('rahul','email@gmail.com','address','213')");
        } catch (Exception $e) {
            die("catch blok");
            return self::response('0', array('error' => $e->getMessage()));
            exit(0);
        }

        return self::response('1', array('sampleData' => $saArray));
    }

    public function response($status, $dataArray = array()) {

        $responseBody = array();
        $responseBody['status'] = $status;
        $responseBody['data'] = $dataArray;
        echo json_encode($responseBody);
        exit(0);
    }

    public function SetHeaders() {
        header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Allow-Headers: Content-Type, Credentials, Authorization, *');
    }

    public function CallAPI($method, $url, $data) {
        $curl = curl_init();
        switch ($method) {
            case "POST":
                curl_setopt($curl, CURLOPT_POST, 1);
                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            case "PUT":
                curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "PUT");
                if ($data)
                    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
                break;
            default:
                if ($data)
                    $url = sprintf("%s?%s", $url, http_build_query($data));
        }

        // OPTIONS:
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
            'APIKEY: 111111111111111111111',
            'Content-Type: application/json',
        ));
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);

        // EXECUTE:
        $result = curl_exec($curl);
        if (!$result) {
            die("Connection Failure");
        }
        curl_close($curl);
        return $result;
    }

}

$UsercontrollerObj = new Usercontroller($_REQUEST);
?>
 
