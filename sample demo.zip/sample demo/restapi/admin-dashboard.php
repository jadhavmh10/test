<?php
include_once 'db-connection.php';
$obj = new database(DB_BLOG);
if (!($obj->db_connect())) {
    die("connect failed");
}

$check_permission = $_SESSION['permission'];
if ($check_permission != '213') {
    header('Location: http://localhost/blogdemo/index.php');
}
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.js"></script>
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">


<?php
if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $pwd = $_POST['pwd'];
    $permission = (isset($_POST['permission']))?$_POST['permission'] : array() ;

    if ($email != '' && $pwd != '') {
        $result = $obj->db_query("INSERT INTO `user`(`email`, `password`) VALUES ('$email','$pwd')");
        $last_insert_id = $obj->db_insert_id();
        if ($last_insert_id > 0) {

            if (count($permission) > 0) {
                for ($i = 0; $i <= count($permission); $i++) {
                    $result1 = $obj->db_query("INSERT INTO `userroles`(`userid`, `userroleid`) VALUES ($last_insert_id,$permission[$i])");
                }
            }
        }
        if ($result > 0) {
            $_SESSION['msg'] = "User Successfully Created";
        }
    }
}


?>

<div>
    <a href="javascript:void(0)" onclick="document.getElementById('createuser').style.display = 'block'">Create User</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="#">read blog</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="#">Write blog</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="#">Edit blog</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <a href="javascript:void(0)">Logout</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</div>

<?php if (isset($_SESSION['msg']) != '') { ?>
    <div class="alert alert-success">
        <strong>Success!</strong> <?php echo $_SESSION['msg'];
    unset($_SESSION['msg']); ?>
    </div>    
<?php } ?>


<div class="container" id="createuser" style="display: none">
    <h4>Create user</h4>
    <form id="createuserform" name="createuserform" method="post" action="">
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
        </div>
        <div class="form-group">
            <label for="pwd">Password:</label>
            <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pwd">
        </div>

        <div class="form-group">
            <label for="pwd">Permission:</label>
            write<input type="checkbox"  value="1" id="write" name="permission[]"> 
            read<input type="checkbox" value="2"   id="read" name="permission[]"> 
            edit<input type="checkbox"  value="3"  id="edit" name="permission[]"> 
        </div>

        <input type="submit" class="btn btn-default" name="submit"> 
    </form>
</div>



