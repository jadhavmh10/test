<?php

session_start();
include_once("main-config.php");
if (!class_exists('database')) {
    include_once("class-database.php");
}
?>