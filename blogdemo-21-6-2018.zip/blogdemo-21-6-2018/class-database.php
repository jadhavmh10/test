<?php

class database {

    var $host;
    var $username;
    var $password;
    var $database;
    var $connid;
    var $db_error;
    var $sql;
    var $cachefile;

    //constructor
    function database($db, $dbhost = null) {

      
        if ($dbhost == null) {
            $this->host = DB_HOST;
        }
        $this->username = DB_USER_NAME;
        $this->password = DB_USER_PASSWORD;
        $this->database = $db;
    }

    //make database connection
    function db_connect() {
        $this->connid = mysqli_connect($this->host, $this->username, $this->password); // OR die("Connection to database fails");
        //mysqli_select_db($this->database,$this->connid);
        if (!$this->connid) {
            return false;
        } else {
            $this->connid->select_db($this->database);
            return true;
        }

        //return true;
    }

    //close mysqli connection
    function db_disconnect() {
        mysqli_close($this->connid);

        return true;
    }

    //executes query
    function db_query($sql) {
        $result = $this->connid->query($sql);


        $this->show_sql_err = 1;

        if ($this->db_error && $this->show_sql_err) {
            //echo "<b>".htmlentities($sql)."</font><br>";
            //echo $this->db_error."</b>";
            //echo "<font><b>Sorry, an error has occurred.<br>Please close the window, refresh the page and try again</b></font>";
        }

        return $result;
    }

    function show_db_error() {
        echo '<br><font color="#FF0000" size="2pt"><b>ERROR:' . $this->db_error . '</b><hr>SQL:' . htmlspecialchars($sql) . '</font>';
        exit;
    }

    function db_fetch_array($result) {
    
        return mysqli_fetch_array($result);
    }

    function db_num_rows($result) {
        return mysqli_num_rows($result);
    }

    function db_fetch_row($result) {
        return mysqli_fetch_row($result);
    }

    function db_count($result) {
        return mysqli_num_rows($result);
    }

    //return mysqli error, if any
    function db_error() {
        $err = mysqli_error();

        if ($err) {
            $this->db_error = '<font class="dberror"><li>' . $err . '</font>';
        }
    }

    function db_insert_id() {
        return mysqli_insert_id();
    }

    function get_affected_rows() {
        return mysqli_affected_rows();
    }

    function db_fetch_all($result, $isSingleValue = 0, &$counter = 0) {
        $all_rows = array();
        $counter = 0;
        while ($row = mysqli_fetch_assoc($result)) {
            if ($isSingleValue == 1)
                $all_rows[$counter] = array_shift($row);
            else
                $all_rows[$counter] = $row;

            $counter++;
        }
        return $all_rows;
    }

    /**
     * Free the memory of db result 
     * @param resource $result
     * @return bool
     */
    function db_free_result($result) {
        return mysqli_free_result($result);
    }

    /**
     * Execute Select Query and Return the result in the array format
     * @param string $sql 
     * @param integer $record_count(byReference)
     * @return array
     */
    function db_ExecQry($sql, &$record_count = 0) {
        $arr = array();
        $res = $this->db_query($sql);
        $arr = $this->db_fetch_all($res, 0, $record_count);
        $this->db_free_result($res);
        return $arr;
    }

    /**
     * Execute Select Query and Return the result in the array format
     * @param string $sql 
     * @param integer $record_count(byReference)
     * @return array
     */
    function db_ExecSingleQry($sql) {
       
        
        $arr = array();
        $res = $this->db_query($sql);
        $arr = $this->db_fetch_array($res);
        $this->db_free_result($res);
        return $arr;
    }

    /**
     * Execute Scalar Query and Return the result
     * @param string $sql  
     * @return string
     */
    function db_ExecScalarQry($sql) {
        $arr = $this->db_ExecSingleQry($sql);
        return $arr[0];
    }

    /**
     * Execute and return group concat Query
     * @param string $sql
     * @param string $glue 
     * @return string
     */
    function db_ExecGroupConcatQry($sql, $glue = ',') {
        $arr = array();
        $res = $this->db_query($sql);
        $arr = $this->db_fetch_all($res, 1);
        $this->db_free_result($res);
        if ($glue == -1)
            return array_filter($arr);
        return implode($glue, array_filter($arr));
    }

    public function db_real_escape_string($sa_string, $flag = true) {
        if ($flag) {
            if (!self::isValidInput($sa_string)) {
                echo "<br/>sorry request page could not found";
                exit;
            }
        }
        return mysqli_real_escape_string($sa_string);
    }

    public function isValidInput($input) {
        $returnFlag = true;
        if (!is_numeric($input)) {
            $blackListArr = array('truncate', 'sleep', 'drop', 'insert', 'update', 'delete', 'select', 'alter');
            $input = strtolower($input);
            foreach ($blackListArr as $delimiter) {
                $expldArr = explode($delimiter, $input);
                if (count($expldArr) > 1) {
                    $returnFlag = false;
                    break;
                }
            }
        }
        return $returnFlag;
    }

    function db_ExecCacheSingleQry($sql, $time = 3600, &$fromCache = 0) {
        $sqlCacheFile = $this->cachefile . '/singlerecord-' . md5($sql) . '.txt';
        $arr = array();
        if (!file_exists($sqlCacheFile) || (time() - filemtime($sqlCacheFile) > $time)) {
            $res = $this->db_query($sql);
            $arr = $this->db_fetch_array($res, MYSQLI_BOTH);
            $this->db_free_result($res);
            file_put_contents($sqlCacheFile, serialize($arr), LOCK_EX);
        } else {
            $fromCache = 1;
            $arr = unserialize(file_get_contents($sqlCacheFile));
        }
        return $arr;
    }

    function db_ExecCacheScalarQry($sql, $time = 3600, &$fromCache = 0) {
        $sqlCacheFile = $this->cachefile . '/recordVal-' . md5($sql) . '.txt';
        $val = '';
        if (!file_exists($sqlCacheFile) || (time() - filemtime($sqlCacheFile) > $time)) {
            $arr = $this->db_ExecSingleQry($sql);
            $val = $arr[0];
            file_put_contents($sqlCacheFile, $val, LOCK_EX);
        } else {
            $fromCache = 1;
            $val = file_get_contents($sqlCacheFile);
        }
        return $val;
    }

    function db_ExecCacheQry($sql, $time = 3600, &$fromCache = 0) {
        $sqlCacheFile = $this->cachefile . '/recordset-' . md5($sql) . '.txt';
        $arr = array();
        if (!file_exists($sqlCacheFile) || (time() - filemtime($sqlCacheFile) > $time)) {
            // Save to cache  
            $res = $this->db_query($sql);
            $arr = $this->db_fetch_all($res, 0, $record_count);
            $this->db_free_result($res);
            file_put_contents($sqlCacheFile, serialize($arr), LOCK_EX);
        } else {
            $fromCache = 1;
            // Retrieve from cache
            $arr = unserialize(file_get_contents($sqlCacheFile));
        }
        return $arr;
    }

    function db_ExecCacheGroupConcatQry($sql, $glue = ',', $time = 3600, &$fromCache = 0) {
        $sqlCacheFile = $this->cachefile . '/groupconcat-' . md5($sql) . '.txt';
        $arr = array();
        if (!file_exists($sqlCacheFile) || (time() - filemtime($sqlCacheFile) > $time)) {
            // Save to cache   
            $res = $this->db_query($sql);
            $arr = $this->db_fetch_all($res, 1);
            $this->db_free_result($res);
            file_put_contents($sqlCacheFile, serialize($arr), LOCK_EX);
        } else {

            // Retrieve from cache
            $fromCache = 1;
            $arr = unserialize(file_get_contents($sqlCacheFile));
        }
        if ($glue == -1)
            return $arr;
        return implode($glue, array_filter($arr));
    }

}

?>