<?php

define("DB_HOST", "localhost");

// Set the username of db.	
define("DB_USER_NAME", "root");

// Set the password of db.
define("DB_USER_PASSWORD", "");

// Set the database name.
define("DB_BLOG", "blogdemo");
?>