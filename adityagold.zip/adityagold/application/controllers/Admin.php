<?php

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model("common_model");
    }

    public function index() {
        $chkuname = $this->session->userdata('uname');
        if (empty($chkuname)) {
            redirect(base_url());
        }
        $this->load->view("admin/dashboard");
    }

    public function addnewshop() {
        $chkuname = $this->session->userdata('uname');
        if (empty($chkuname)) {
            redirect(base_url());
        }
        $dataArray = array();
        $dataArray['status'] = 0;
        if ($this->input->post('shopname') != '' && $this->input->post('shoptype') != '' && $this->input->post('shopcode') != '') {
            $insertArray = array(
                'shop_name' => $this->input->post('shopname'),
                'shop_type' => $this->input->post('shoptype'),
                'shop_code' => $this->input->post('shopcode'),
                'db_add_date' => date("Y-m-d")
            );
            $insertid = $data = $this->common_model->insertblog("shop_master", $insertArray);
            if ($insertid > 0) {
                $dataArray['status'] = 1;
                $this->session->set_userdata('msg', 'Your Shop Added Successfully !!!');
            }
        }
        $this->load->view("admin/addshop", $dataArray);
    }

    public function shoplist() {

        $chkuname = $this->session->userdata('uname');
        if (empty($chkuname)) {
            redirect(base_url());
        }
        $dataArray = array();
        $dataArray['shoplist'] = $this->common_model->getrecoreds("shop_master", $fields = array(), $condition = array(), $limit = 100, $offset = 0, $orderby = 'db_add_date DESC');
        $this->load->view("admin/shoplist", $dataArray);
    }

    public function expenditure() {
        $chkuname = $this->session->userdata('uname');
        if (empty($chkuname)) {
            redirect(base_url());
        }
        $dataArray = array();
        $dataArray['status'] = 0;
        $purticular = $this->input->post('purticular');
        $shop_id = $this->input->post('shop_id');
        $amt = $this->input->post('amt');

        if ($purticular != '' && $shop_id != '' && $amt != '') {
            $insertArray = array('purticular' => $purticular, 'shop_id' => $shop_id, 'ammount' => $amt, 'db_add_date' => date("Y-m-d"));
            $insertid = $data = $this->common_model->insertblog("expenditure", $insertArray);
            if ($insertid > 0)
                $dataArray['status'] = 1;
        }

        $dataArray['shoplist'] = $this->common_model->getrecoreds("shop_master", $fields = array(), $condition = array(), $limit = 100, $offset = 0, $orderby = 'db_add_date DESC');


        $this->load->view("admin/expenditure", $dataArray);
    }

    public function income() {
        $chkuname = $this->session->userdata('uname');
        if (empty($chkuname)) {
            redirect(base_url());
        }
        $dataArray = array();
        $dataArray['status'] = 0;
        $incomesource = $this->input->post('incomesource');
        $shop_id = $this->input->post('shop_id');
        $amt = $this->input->post('amt');

        if ($incomesource != '' && $shop_id != '' && $amt != '') {
            $insertArray = array('incomesource' => $incomesource, 'shop_id' => $shop_id, 'ammount' => $amt, 'db_add_date' => date("Y-m-d"));
            $insertid = $data = $this->common_model->insertblog("income", $insertArray);
            if ($insertid > 0)
                $dataArray['status'] = 1;
        }

        $dataArray['shoplist'] = $this->common_model->getrecoreds("shop_master", $fields = array(), $condition = array(), $limit = 100, $offset = 0, $orderby = 'db_add_date DESC');


        $this->load->view("admin/income", $dataArray);
    }

    public function report() {
        $chkuname = $this->session->userdata('uname');
        if (empty($chkuname)) {
            redirect(base_url());
        }
        $dataArray = array();

        $dataArray['shoplist'] = $this->common_model->getrecoreds("shop_master", $fields = array(), $condition = array(), $limit = 100, $offset = 0, $orderby = 'db_add_date DESC');
        if ($this->input->post("start") != '' && $this->input->post("end")) {
            $start = $this->input->post("start");
            $end = $this->input->post("end");
            $shopid = $this->input->post("shopname");


//            $dataArray['expense'] = $this->common_model->getrecoreds("expenditure", $fields = array(), $condition = array("db_add_date >=" => $start, "db_add_date <=" => $end), 5000, 0, 'db_add_date DESC');
            //            $dataArray['income'] = $this->common_model->getrecoreds("income", $fields = array(), $condition = array("db_add_date >=" => $start, "db_add_date <=" => $end), 5000, 0, 'db_add_date DESC');

            $dataArray['expense'] = $this->common_model->get_expenditure_report($start, $end,$shopid);
            $dataArray['income'] = $this->common_model->get_income_report($start, $end,$shopid);
            $totalexpense = $this->common_model->totalexpense($start, $end,$shopid);
            $totalincome = $this->common_model->totalincome($start, $end,$shopid);
            $dataArray['totalexpense'] = $totalexpense;
            $dataArray['totalincome'] = $totalincome;
        }


        $this->load->view("admin/report", $dataArray);
    }

}

?>
